let users = [

    {"username": "jk", "password": "sala", "token": ""},
    
    {"username": "pl", "password": "pass", "token": ""},

]


let data = [

    {"id": "1", "Firstname": "Marco", "Surname": "Berrocal"},
    {"id": "2","Firstname": "Berrocal", "Surname": "Marco"}

]


const getUsers = () => {
    return users;
}


const getData = () => {
    return data;
}


export {
    getData
}


export {
    getUsers
}